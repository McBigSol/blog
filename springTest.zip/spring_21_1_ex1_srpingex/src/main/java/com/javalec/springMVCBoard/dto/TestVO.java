package com.javalec.springMVCBoard.dto;

public class TestVO {

	public String id;
	public String password;

	public TestVO() {
		// TODO 自動生成されたコンストラクター・スタブ
	}

	public TestVO(String id, String password) {
		super();
		this.id = id;
		this.password = password;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "TestVO [id=" + id + ", password=" + password + "]";
	}

}
