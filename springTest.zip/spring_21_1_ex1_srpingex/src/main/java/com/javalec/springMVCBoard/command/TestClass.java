package com.javalec.springMVCBoard.command;

import java.util.ArrayList;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import com.javalec.springMVCBoard.dao.BDao;
import com.javalec.springMVCBoard.dto.TestVO;

public class TestClass implements BCommand{

	@Override
	public void execute(Model model) {
		// TODO 自動生成されたメソッド・スタブ
		BDao dao = new BDao();
		ArrayList<TestVO> dtos = dao.test();

		for(int i=0; i< dtos.size(); i++){
			System.out.println(dtos.get(i));
		}

		model.addAttribute("test", dtos);

	}

}